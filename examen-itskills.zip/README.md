# examen-itskills

Ejercicio

**Sistema**

Realizar 2 pantallas:

**Lista de Facturas**
se ve un listado con fecha, cantidad de items y total de la factura
**Detalle de Factura**
donde se ve la fecha, itemizado de productos (descripcion, cantidad, precio unitario, subtotal) y total de la
Factura


Desarrollo
Para ello se debera generar las tablas en una base de datos MySQL/MariaDB y realizar el codigo
correspondiente. Utilizando framework a elección
Solo se necesita pantallas de consulta. Una pantalla de edición de factura no es obligatorio.
Se considera un plus si se puede poner como JSON como formato de respuesta.


**Metodo de Evaluación**
Se modificará los datos en las tablas de la base de Datos y se observarán los resultados.
Nos importa solo la parte del codigo correspondiente al back-end (controllers/archivos) y base de datos
(tablas, columnas, indexes).

No se evaluará codigo HTML ni nada de front-end
Además tambien se revisará el codigo donde se evaluará:
Calidad
Buenas practicas